<?php
include ("header.php");
?>

<h1>Welcome! </h1>
<p>Welcome to my site!</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sed imperdiet purus, et eleifend odio. Nulla non luctus neque. In condimentum quam eu orci luctus, in imperdiet odio blandit. Integer dictum elementum lorem, vel suscipit quam lobortis quis. Donec scelerisque enim vel tempus sodales. Curabitur sollicitudin, risus in tempor porttitor, eros purus hendrerit quam, vitae iaculis mi lectus vel dui. Integer quis suscipit neque. Phasellus ullamcorper pulvinar lectus eget viverra. </p>
<p>You can also find about:</p>
<ul>
    <li>My interests</li>
    <li>My dogs</li>
    <li>Stuff</li>
</ul>

<?php require ("footer.php"); ?>

