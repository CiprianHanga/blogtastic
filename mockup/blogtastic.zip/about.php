<?php
require ("header.php");
?>
<h1>About Me</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis consequat ligula fringilla pretium fermentum. Nullam non sapien dui. Ut nec turpis a lacus iaculis pretium. Sed malesuada ex in ante bibendum, sed sagittis dui vestibulum. Mauris sed vestibulum magna. Curabitur eget ullamcorper lectus. Ut condimentum eros nec ullamcorper consequat. Sed rhoncus consequat feugiat. Proin scelerisque mollis ornare. Integer ac massa rutrum, ullamcorper magna eu, consectetur lacus. Aliquam consequat, mauris sed efficitur faucibus, augue neque pretium nulla, maximus sollicitudin libero ex sed orci. Praesent feugiat arcu urna, sit amet consequat neque molestie sed. Maecenas pretium venenatis est, ac accumsan metus dictum vel. Sed odio velit, bibendum eu bibendum vitae, semper et turpis. Nullam elit dolor, aliquet eget erat eget, bibendum pretium ipsum. </p>
<h2>More Details</h2>
<p>Proin vel aliquam arcu. Maecenas sit amet imperdiet tortor. Vivamus nec gravida lorem. Mauris eget nulla non mauris hendrerit semper. Integer eu metus vitae nunc blandit faucibus in malesuada felis. Nam at purus posuere augue feugiat malesuada semper sit amet augue. Proin id turpis at nunc convallis scelerisque bibendum nec risus. Curabitur convallis, nisi vel consectetur venenatis, nisl odio semper eros, in porttitor arcu enim ut enim. Fusce pretium finibus purus, in condimentum mi egestas nec. Mauris urna ipsum, placerat sed nisl sit amet, maximus tempor diam. </p>
<h3>Even More</h3>
<p>Donec congue leo enim, eget viverra urna accumsan sodales. Quisque magna sem, porttitor vitae nibh sit amet, luctus condimentum neque. Vestibulum tincidunt mi quis dolor placerat, at porttitor nisi consequat. Donec nibh est, vehicula vitae sem ac, auctor finibus lectus. Suspendisse maximus, nibh eu suscipit vestibulum, quam turpis suscipit nunc, in vulputate ante sapien pellentesque sem. Duis convallis elit elit, at sagittis arcu dignissim sed. Donec diam lectus, maximus vel vehicula vel, lobortis non erat. Phasellus in quam neque. Cras et metus vitae risus ornare vulputate. Donec lacinia vel urna sed suscipit. Aenean tellus erat, consequat ac placerat eget, lacinia eget purus. Aenean a commodo odio. Praesent varius leo ac nulla sodales lobortis. Cras interdum finibus bibendum. Donec a finibus orci. </p>
<?php
require ("footer.php");

