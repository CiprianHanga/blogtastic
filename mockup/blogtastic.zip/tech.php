<?php
require ("header.php");
?>
<h1>Technical Details</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc tincidunt, nisi eget porttitor sodales, purus nisl eleifend metus, at condimentum mauris libero nec risus. Cras faucibus urna ac est porttitor, non vehicula nulla commodo. Nulla facilisi. In ornare erat quis tristique aliquet. Suspendisse diam orci, cursus ut molestie eget, volutpat aliquet orci. Nam porttitor sapien id quam vulputate, sit amet venenatis odio finibus. Donec sit amet lectus quis risus semper tristique. Duis tincidunt libero ac suscipit aliquam. Pellentesque sodales sollicitudin velit id vulputate. </p>

<table cellspacing="0" cellpadding="10">
    <tr>
        <th>Tool</th>
        <th>Version</th>
        <th>Description</th>
    </tr>
    <tr>
        <td>PHP</td>
        <td>4.x and 5.x</td>
        <td>Scripting language for web applications</td>
    </tr>
    <tr>
        <td>MySQL</td>
        <td>4.x</td>
        <td>Powerful database system</td>
    </tr>
</table>

<?php
require ("footer.php");
?>