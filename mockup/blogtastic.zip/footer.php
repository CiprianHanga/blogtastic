</div> <!-- closes "main" div -->
</div> <!-- closes "container" div -->



<div id="footer">
&copy; <?php echo $config_author; ?>
</div> <!-- closes "footer" div-->
</div> <!-- closes "wrapper" div -->
</body>
</html>