<?php
require ("header.php");
?>
<h1 id="top">Frequently Asked Questions</h1>
<ul>
<li><a href="#1">Ipsum, eu consectetuer, praesent ad, lobortis veniam.</a></li>
<li><a href="#2">Autem illum suscipit volutpat exerci adipisci in lorem.</a></li>
<li><a href="#3">Luptatum suscipit.</a></li>
<li><a href="#4">Qui veniam accumsan tincidunt veniam.</a></li>
<li><a href="#5">At iriure amet et odio.</a></li>
</ul>

<h2 id="1">Ipsum, eu consectetuer, praesent ad, lobortis veniam.</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sed imperdiet purus, et eleifend odio. Nulla non luctus neque. In condimentum quam eu orci luctus, in imperdiet odio blandit. Integer dictum elementum lorem, vel suscipit quam lobortis quis. Donec scelerisque enim vel tempus sodales. Curabitur sollicitudin, risus in tempor porttitor, eros purus hendrerit quam, vitae iaculis mi lectus vel dui. Integer quis suscipit neque. Phasellus ullamcorper pulvinar lectus eget viverra. </p>
<p><a href="#top">Back to the top</a></p>

<h2 id="2">Autem illum suscipit volutpat exerci adipisci in lorem.</h2>
<p>Nam commodo venenatis accumsan. Suspendisse at imperdiet arcu. Mauris mi sem, viverra at posuere ut, condimentum nec ante. Sed tempus nunc tincidunt efficitur fermentum. Vivamus ac ipsum sed tortor tristique mollis quis sed libero. Proin vestibulum non mauris a sollicitudin. Nam sit amet dapibus quam. Maecenas ornare ex quis massa dapibus aliquam. Mauris vel bibendum lorem, et tempus metus. Curabitur sed enim ultrices, sodales nisi in, pharetra dolor. Curabitur tempor elit ac odio volutpat ultricies. Vestibulum in laoreet libero. </p>
<p><a href="#top">Back to the top</a></p>

<h2 id="3">Luptatum suscipit.</h2>
<p>Curabitur et lacus ex. Praesent varius mollis accumsan. Aliquam erat volutpat. Aenean eu eros ut mauris varius pretium et eu nulla. Nullam et magna porttitor, vulputate augue at, tempor dui. Nulla sagittis et neque lacinia vestibulum. Suspendisse eu quam diam. Donec ut nisl ante. Sed lacinia mauris et velit auctor dignissim. Ut elementum bibendum purus, in vestibulum tortor vulputate at. Donec volutpat rutrum vestibulum. Praesent viverra ex nec nibh lobortis, eu lacinia mauris fringilla. </p>
<p><a href="#top">Back to the top</a></p>

<h2 id="4">Qui veniam accumsan tincidunt veniam.</h2>
<p>Donec vehicula, orci a pulvinar luctus, erat leo vulputate leo, sit amet laoreet urna nisi eget purus. Suspendisse in dignissim nisi, nec semper libero. Cras tempor sagittis mi ut scelerisque. Duis et odio vehicula, eleifend nibh nec, euismod lacus. Suspendisse gravida fringilla neque in condimentum. Ut nisl felis, tincidunt nec dolor ac, fermentum pharetra magna. Vivamus tempor convallis tincidunt. Sed molestie tincidunt magna, et suscipit nulla faucibus sed. Aliquam enim mauris, ultrices sed rutrum non, pharetra vel enim. Donec eu auctor nibh. Donec ut finibus est, eget faucibus odio. Proin ultricies nulla sit amet vestibulum porttitor. </p>
<p><a href="#top">Back to the top</a></p>

<h2 id="5">At iriure amet et odio.</h2>
<p>Nam eu hendrerit turpis, id auctor nibh. Ut sodales a libero nec blandit. Morbi condimentum feugiat nibh, quis efficitur augue placerat posuere. Maecenas id sapien leo. Quisque tempor venenatis pretium. Fusce consequat et ipsum vel elementum. Donec condimentum finibus egestas. Proin ut turpis quis nunc feugiat aliquam. Aenean fringilla, libero nec dictum interdum, lorem nisi elementum orci, pulvinar congue nibh quam a dolor. In scelerisque dui non aliquam molestie. Interdum et malesuada fames ac ante ipsum primis in faucibus. Duis suscipit tempus elit ac vestibulum. Ut auctor turpis urna, eu rhoncus felis vehicula sit amet. </p>
<p><a href="#top">Back to the top</a></p>


<?php
require ("footer.php");
?>